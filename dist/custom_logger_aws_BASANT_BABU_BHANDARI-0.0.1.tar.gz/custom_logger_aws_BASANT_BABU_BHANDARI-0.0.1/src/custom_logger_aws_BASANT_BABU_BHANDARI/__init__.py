"""
custom logger module for aws batch and aws lambda
author: Basant Babu Bhandari
"""