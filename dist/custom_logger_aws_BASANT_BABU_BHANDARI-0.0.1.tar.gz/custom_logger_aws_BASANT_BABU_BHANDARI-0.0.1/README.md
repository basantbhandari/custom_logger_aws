# custom logger aws serverless

This is the project for improving aws serverless logging system in order to better moniter the system. You can use this python package by running the following command

command used to install:
```
python3 -m pip install custom_logger_aws_BASANT_BABU_BHANDARI
```